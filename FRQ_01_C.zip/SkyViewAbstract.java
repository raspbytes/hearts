public abstract class SkyViewAbstract {
  protected double[][] view;

  public SkyViewAbstract(int numRows, int numCols, double[] scanned) {
    System.out.println("[Abstract stub] SkyView constructor called");
    view = new double[numRows][numCols];
  }

  public double[][] getView() {
    return view;
  }
}
