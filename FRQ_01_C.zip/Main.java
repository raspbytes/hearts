import java.util.*;
import java.lang.reflect.*;

public class Main {

  static Scanner sc;

  public static void main(String[] args) {
    System.out.println("Hello LASA Free Response 1!");

    sc = new Scanner(System.in);

    reportStatus(); // Optional: show readiness status for all classes

    System.out.print("Enter test to run (1a, 1b, 2, 3, 0): ");
    String choice = sc.next();
    sc.nextLine();
    System.out.println();

    switch (choice) {
      case "1a":
      case "1b":
        if (
          classHasMethods("DownloadInfo", "getTitle", "getTimesDownloaded") &&
          classHasMethods("MusicDownloads", "getDownloadInfo", "updateDownloads", "toString")
        ) {
          System.out.println("Music Download Test");
          musicDownloadTest(choice);
        }
        break;

      case "2":
        if (classHasMethods("TokenPass", "getCurrentPlayer", "distributeCurrentPlayerTokens", "setBoard", "setCurrentPlayer", "toString")) {
          System.out.println("Token Pass Test");
          tokenPassTest();
        }
        break;

      case "3":
        if (classHasMethods("SkyView", "getView")) {
          System.out.println("Sky View Test");
          skyViewTest();
        }
        break;

      case "0":
        boolean mdReady = classHasMethods("DownloadInfo", "getTitle", "getTimesDownloaded") &&
                          classHasMethods("MusicDownloads", "getDownloadInfo", "updateDownloads", "toString");
        boolean tpReady = classHasMethods("TokenPass", "getCurrentPlayer", "distributeCurrentPlayerTokens", "setBoard", "setCurrentPlayer", "toString");
        boolean svReady = classHasMethods("SkyView", "getView");

        if (mdReady) musicDownloadTest("1b");
        if (tpReady) tokenPassTest();
        if (svReady) skyViewTest();
        break;
    }
  }

  /*
*/
  public static boolean classHasMethods(String className, String... methodNames) {
  try {
    Class<?> cls = Class.forName(className);
    List<String> foundMethods = new ArrayList<>();
    for (Method method : cls.getMethods()) { // <-- change from getDeclaredMethods()
      foundMethods.add(method.getName());
    }

    for (String methodName : methodNames) {
      if (!foundMethods.contains(methodName)) {
        System.out.println("Class " + className + " is missing method: " + methodName);
        return false;
      }
    }

    return true;
  } catch (ClassNotFoundException e) {
    System.out.println("Class " + className + " not found.");
    return false;
  }
}

  public static void reportStatus() {
    System.out.println("Checking readiness of components...\n");

    String[][] classAndMethods = {
      {"DownloadInfo", "getTitle", "getTimesDownloaded"},
      {"MusicDownloads", "getDownloadInfo", "updateDownloads", "toString"},
      {"TokenPass", "getCurrentPlayer", "distributeCurrentPlayerTokens", "setBoard", "setCurrentPlayer", "toString"},
      {"SkyView", "getView"}
    };

    for (String[] entry : classAndMethods) {
      String className = entry[0];
      String[] methods = Arrays.copyOfRange(entry, 1, entry.length);
      boolean ok = classHasMethods(className, methods);
      System.out.println("- " + className + ": " + (ok ? "READY" : "MISSING METHOD(S)"));
    }

    System.out.println();
  }

  public static void musicDownloadTest(String choice) {
    try {
      Class<?> infoClass = Class.forName("DownloadInfo");
      Object d1 = infoClass.getConstructor(String.class, int.class).newInstance("Hey Jude", 5);
      Object d2 = infoClass.getConstructor(String.class, int.class).newInstance("Soul Sister", 3);
      Object d3 = infoClass.getConstructor(String.class, int.class).newInstance("Aqualung", 10);
      Object d4 = infoClass.getConstructor(String.class, int.class).newInstance("Arc of a Diver", 27);

      List<Object> downloadList = new ArrayList<>();
      downloadList.add(d1);
      downloadList.add(d2);
      downloadList.add(d3);

      Class<?> musicClass = Class.forName("MusicDownloads");
      Constructor<?> ctor = musicClass.getConstructor(List.class);
      Object music = ctor.newInstance(new ArrayList<>(downloadList));
      downloadList.add(d4);

      Method getInfo = musicClass.getMethod("getDownloadInfo", String.class);
      Method update = musicClass.getMethod("updateDownloads", List.class);

      System.out.println("*** Initial download data\n" + music.toString());
      System.out.println("*** Testing getDownloadInfo()...");
      System.out.println(getInfo.invoke(music, "Aqualung"));
      System.out.println(getInfo.invoke(music, "Happy Birthday"));
      System.out.println(getInfo.invoke(music, "Arc of a Diver"));

      if (choice.equals("1b")) {
        List<String> songs = Arrays.asList("Lights", "Aqualung", "Soul Sister", "Go Now", "Lights", "Soul Sister");
        update.invoke(music, songs);
        System.out.println("\n*** Testing getDownloadInfo()\n" + music.toString());
      }
    } catch (Exception e) {
      System.out.println("Error running musicDownloadTest.");
      e.printStackTrace();
    }
  }

  public static void tokenPassTest() {
    try {
      Class<?> tokenClass = Class.forName("TokenPass");
      Constructor<?> ctor = tokenClass.getConstructor(int.class);
      Object test = ctor.newInstance(4);
      Object test2 = ctor.newInstance(4);

      Method toStringMethod = tokenClass.getMethod("toString");
      if (toStringMethod.invoke(test).equals(toStringMethod.invoke(test2)))
        System.out.println("Token board creation error!");
      else
        System.out.println("Token board creation success!");

      Method setBoard = tokenClass.getMethod("setBoard", int[].class);
      Method setCurrent = tokenClass.getMethod("setCurrentPlayer", int.class);
      Method getCurrent = tokenClass.getMethod("getCurrentPlayer");
      Method distribute = tokenClass.getMethod("distributeCurrentPlayerTokens");

      int[] board = {5, 9, 9, 5};
      setBoard.invoke(test, (Object) board);
      setCurrent.invoke(test, 2);
      System.out.println("Current player = " + getCurrent.invoke(test));
      distribute.invoke(test);
      System.out.println(toStringMethod.invoke(test));

      ////////////
    //TokenPass tp = new TokenPass(4);
    setBoard.invoke(test, new int[] {2, 1, 6, 1});
      setCurrent.invoke(test, 2);    // player at index 2 has 6 tokens
      distribute.invoke(test);
      System.out.println(toStringMethod.invoke(test));
    //int[] expected = {4, 2, 0, 2};
    //assertArrayEquals("Tokens should wrap and distribute correctly", expected, tp.getBoard());
      ////////////

    } catch (Exception e) {
      System.out.println("Error running tokenPassTest.");
      e.printStackTrace();
    }
  }

  public static void skyViewTest() {
    try {
      Class<?> skyClass = Class.forName("SkyView");
      Constructor<?> ctor = skyClass.getConstructor(int.class, int.class, double[].class);
      Method getView = skyClass.getMethod("getView");

      double[] values = {0.3, 0.7, 0.8, 0.4, 1.4, 1.1, 0.2, 0.5, 0.1, 1.6, 0.6, 0.9};
      Object sView = ctor.newInstance(4, 3, values);
//          double[] input = {0.3, 0.7, 0.8, 0.4, 1.4, 1.1};
//      Object sView = ctor.newInstance(3, 2, input);
      double[][] view = (double[][]) getView.invoke(sView);

      System.out.println("It should print the following:");
      System.out.println("0.3, 0.7, 0.8,");
      System.out.println("1.1, 1.4, 0.4,");
      System.out.println("0.2, 0.5, 0.1,");
      System.out.println("0.9, 0.6, 1.6,");
      System.out.println("\nYour results");
      printMatrix(view);

      double[] values2 = {0.3, 0.7, 0.8, 0.4, 1.4, 1.1};
      sView = ctor.newInstance(3, 2, values2);
      view = (double[][]) getView.invoke(sView);
      System.out.println("It should print the following:");
      System.out.println("0.3, 0.7,");
      System.out.println("0.4, 0.8,");
      System.out.println("1.4, 1.1,");
      System.out.println("\nYour results");
      printMatrix(view);

    } catch (Exception e) {
      System.out.println("Error running skyViewTest.");
      e.printStackTrace();
    }
  }

  private static void printMatrix(double[][] matrix) {
    for (double[] row : matrix) {
      for (double val : row) {
        System.out.print(val + ", ");
      }
      System.out.println();
    }
  }
}
