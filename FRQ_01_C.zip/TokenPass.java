import java.util.*;

public class TokenPass extends TokenPassAbstract {

  public TokenPass(int playerCount) {
    super(playerCount);
    int pC = playerCount;

    private int[] board = new int[pC];
    for (i : board){
      board[i] = (Math.random())+1;
    }

    private int currentPlayer =(Math.random()) + pC;
    
  }

  @Override
  public void distributeCurrentPlayerTokens() {
    for (int i = 0; i<board.size; i++){
      int nT = board[i]; //current idx
      int pNum = i;

      for (int j = i, j<board.size; j++){
        board[(j+1)%board.size]++;
        board[i]--; //keep same
        nT--; //decrement
      }
    }
//wraparound
  /*  if (nT==0 && i >= board.size){
       board[0]++;
       board[i]--;
        nT--;
    }*/
    
  }

  // Optionally override toString if needed
}
