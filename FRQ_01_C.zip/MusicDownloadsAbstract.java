import java.util.*;

public abstract class MusicDownloadsAbstract {
  protected List<DownloadInfo> downloadList;

  public MusicDownloadsAbstract(List<DownloadInfo> initialize) {
    this.downloadList = new ArrayList<>(initialize);
  }

  /**
   * Returns a reference to the DownloadInfo object with the matching title, or null if not found.
   */
  public DownloadInfo getDownloadInfo(String title) {
    System.out.println("[Abstract stub] getDownloadInfo called with: " + title);
    return null;
  }

  /**
   * Updates the download list with the provided titles.
   */
  public void updateDownloads(List<String> titles) {
    System.out.println("[Abstract stub] updateDownloads called with: " + titles);
  }

  /**
   * Returns a string representation of the download list.
   */
  public String toString() {
    return "[Abstract stub] MusicDownloads: " + downloadList.toString();
  }
}
