import java.util.*;

public class MusicDownloads extends MusicDownloadsAbstract {

  public MusicDownloads(List<DownloadInfo> initialize) {
    super(initialize);
  }

  // TODO: Implement getDownloadInfo
  @Override
  public DownloadInfo getDownloadInfo(String title) {
    // return the DownloadInfo object for the matching title
    return null;
  }

  // TODO: Implement updateDownloads
  @Override
  public void updateDownloads(List<String> titles) {
   for (String n : titles){
     if (downloadList.contains(titles.get(n)){
       downloadList.incrementTimesDownloaded();
     }
    else{
      DownloadInfo newDownload = new DownloadInfo(titles.get(n), 1);
    }
   }
  }

  // Optional: override toString to improve display
  @Override
  public String toString() {
    return downloadList.toString();
  }
}
