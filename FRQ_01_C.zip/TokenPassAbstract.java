public abstract class TokenPassAbstract {
  protected int[] board;
  protected int currentPlayer;

  public TokenPassAbstract(int playerCount) {
    board = new int[playerCount];
    for (int i = 0; i < board.length; i++) {
      board[i] = i; // placeholder tokens for test scaffold
    }
    currentPlayer = 0;
  }

  public void setBoard(int[] b) {
    board = b.clone();
  }

  public void setCurrentPlayer(int cp) {
    currentPlayer = cp;
  }

  public int[] getBoard() {
    return board.clone(); // defensive copy
  }

  public int getCurrentPlayer() {
    return currentPlayer;
  }

  public void distributeCurrentPlayerTokens() {
    System.out.println("[Abstract stub] distributeCurrentPlayerTokens called");
  }

  public String toString() {
    StringBuilder sb = new StringBuilder("Board: ");
    for (int token : board) {
      sb.append(token).append(" ");
    }
    sb.append(" CurrentPlayer: ").append(currentPlayer);
    return sb.toString().trim();
  }
}
